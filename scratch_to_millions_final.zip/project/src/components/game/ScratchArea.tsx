import * as React from 'react';
import { StyleSheet, GestureEventData } from 'react-nativescript';
import type { ScratchCard } from '../../types/game';

interface Props {
  card: ScratchCard;
  onScratch: () => void;
}

export function ScratchArea({ card, onScratch }: Props) {
  const handlePan = (args: GestureEventData) => {
    if (card.status === 'available') {
      onScratch();
    }
  };

  return (
    <gridLayout style={styles.container}>
      {card.status === 'available' ? (
        <stackLayout style={styles.scratchLayer} onPan={handlePan}>
          <label style={styles.instruction}>Scratch here!</label>
        </stackLayout>
      ) : (
        <stackLayout style={styles.prizeContainer}>
          <label style={styles.prizeAmount}>
            {card.prize?.amount} {card.prize?.type}
          </label>
        </stackLayout>
      )}
    </gridLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 200,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    margin: 16,
  },
  scratchLayer: {
    backgroundColor: '#E0E0E0',
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  instruction: {
    fontSize: 18,
    color: '#757575',
  },
  prizeContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  prizeAmount: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
});