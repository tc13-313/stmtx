import * as React from 'react';
import { StyleSheet } from 'react-nativescript';
import type { UserBalance } from '../../types/auth';

interface Props {
  balance: UserBalance;
}

export function BalanceDisplay({ balance }: Props) {
  return (
    <stackLayout style={styles.container}>
      <gridLayout style={styles.balanceGrid} columns="*, *" rows="auto">
        <stackLayout col={0} style={styles.balanceItem}>
          <label style={styles.amount}>{balance.stmBucks}</label>
          <label style={styles.label}>STM Bucks</label>
        </stackLayout>
        <stackLayout col={1} style={styles.balanceItem}>
          <label style={styles.amount}>{balance.points}</label>
          <label style={styles.label}>Points</label>
        </stackLayout>
      </gridLayout>
    </stackLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
  },
  balanceGrid: {
    gap: 16,
  },
  balanceItem: {
    alignItems: 'center',
  },
  amount: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4CAF50',
  },
  label: {
    fontSize: 14,
    color: '#757575',
  },
});