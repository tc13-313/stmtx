import * as React from 'react';
import { StyleSheet } from 'react-nativescript';
import { TextField } from '../common/TextField';
import { Button } from '../common/Button';

interface Props {
  onSubmit: (email: string, password: string) => void;
  loading: boolean;
}

export function LoginForm({ onSubmit, loading }: Props) {
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');

  const handleSubmit = () => {
    onSubmit(email, password);
  };

  return (
    <stackLayout style={styles.container}>
      <TextField
        value={email}
        onTextChange={setEmail}
        hint="Email"
        keyboardType="email"
      />
      <TextField
        value={password}
        onTextChange={setPassword}
        hint="Password"
        secure={true}
      />
      <Button
        text={loading ? 'Logging in...' : 'Login'}
        onTap={handleSubmit}
        disabled={loading}
      />
    </stackLayout>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: 16,
    padding: 16,
  },
});