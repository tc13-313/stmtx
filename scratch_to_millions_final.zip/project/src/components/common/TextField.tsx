import * as React from 'react';
import { StyleSheet } from 'react-nativescript';

interface Props {
  value: string;
  onTextChange: (text: string) => void;
  hint?: string;
  secure?: boolean;
  keyboardType?: 'email' | 'number' | 'text';
}

export function TextField({ 
  value, 
  onTextChange, 
  hint, 
  secure = false,
  keyboardType = 'text' 
}: Props) {
  return (
    <textField
      style={styles.input}
      text={value}
      onTextChange={(args) => onTextChange(args.value)}
      hint={hint}
      secure={secure}
      keyboardType={keyboardType}
    />
  );
}

const styles = StyleSheet.create({
  input: {
    fontSize: 16,
    padding: 12,
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
  },
});