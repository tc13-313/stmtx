import * as React from 'react';
import { StyleSheet } from 'react-nativescript';

interface Props {
  text: string;
  onTap: () => void;
  disabled?: boolean;
  variant?: 'primary' | 'secondary';
}

export function Button({ text, onTap, disabled = false, variant = 'primary' }: Props) {
  return (
    <button
      style={[styles.button, styles[variant], disabled && styles.disabled]}
      onTap={disabled ? undefined : onTap}
    >
      <label style={[styles.text, disabled && styles.disabledText]}>{text}</label>
    </button>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: 8,
    padding: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  primary: {
    backgroundColor: '#4CAF50',
  },
  secondary: {
    backgroundColor: '#757575',
  },
  disabled: {
    opacity: 0.5,
  },
  text: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  disabledText: {
    color: '#E0E0E0',
  },
});