import { ApplicationSettings } from '@nativescript/core';
import type { Achievement, Reward } from '../types/rewards';

const ACHIEVEMENTS_KEY = 'user_achievements';

export class RewardsService {
  static async getAchievements(): Promise<Achievement[]> {
    const stored = ApplicationSettings.getString(ACHIEVEMENTS_KEY);
    return stored ? JSON.parse(stored) : [];
  }

  static async updateProgress(achievementId: string, progress: number): Promise<Achievement> {
    const achievements = await this.getAchievements();
    const achievement = achievements.find(a => a.id === achievementId);
    
    if (!achievement) {
      throw new Error('Achievement not found');
    }

    achievement.progress = Math.min(progress, achievement.target);
    achievement.completed = achievement.progress >= achievement.target;
    
    if (achievement.completed && !achievement.completedAt) {
      achievement.completedAt = new Date();
    }

    ApplicationSettings.setString(ACHIEVEMENTS_KEY, JSON.stringify(achievements));
    return achievement;
  }

  static async claimReward(achievementId: string): Promise<Reward> {
    const achievements = await this.getAchievements();
    const achievement = achievements.find(a => a.id === achievementId);
    
    if (!achievement || !achievement.completed) {
      throw new Error('Achievement not completed');
    }

    return achievement.reward;
  }
}