import { ApplicationSettings } from '@nativescript/core';
import type { BalanceUpdate, BalanceState } from '../types/balance';

const BALANCE_KEY = 'user_balance';
const HISTORY_KEY = 'balance_history';

export class BalanceService {
  static async getBalance(): Promise<BalanceState> {
    const stored = ApplicationSettings.getString(BALANCE_KEY);
    return stored ? JSON.parse(stored) : { stmBucks: 0, points: 0, history: [], loading: false, error: null };
  }

  static async updateBalance(update: BalanceUpdate): Promise<BalanceState> {
    const current = await this.getBalance();
    const newBalance = {
      ...current,
      [update.type]: current[update.type] + update.amount,
      history: [update, ...current.history]
    };
    
    ApplicationSettings.setString(BALANCE_KEY, JSON.stringify(newBalance));
    return newBalance;
  }
}