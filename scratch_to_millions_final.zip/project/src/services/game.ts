import { ApplicationSettings } from '@nativescript/core';
import type { ScratchCard, Prize } from '../types/game';
import { generateRandomPrize } from '../utils/prizeGenerator';

const DAILY_CARD_KEY = 'daily_card_timestamp';
const CURRENT_CARD_KEY = 'current_scratch_card';

export class GameService {
  static async getDailyCardStatus(): Promise<boolean> {
    const lastPlayed = ApplicationSettings.getString(DAILY_CARD_KEY);
    if (!lastPlayed) return true;

    const lastPlayedDate = new Date(lastPlayed);
    const today = new Date();
    return lastPlayedDate.getDate() !== today.getDate();
  }

  static async createNewCard(type: ScratchCard['type']): Promise<ScratchCard> {
    const card: ScratchCard = {
      id: Date.now().toString(),
      type,
      cost: type === 'premium' ? 100 : 0,
      status: 'available',
    };

    ApplicationSettings.setString(CURRENT_CARD_KEY, JSON.stringify(card));
    return card;
  }

  static async scratchCard(cardId: string): Promise<Prize> {
    const prize = generateRandomPrize();
    const card = await this.getCurrentCard();
    
    if (card && card.id === cardId) {
      card.status = 'scratched';
      card.prize = prize;
      card.scratchedAt = new Date();
      ApplicationSettings.setString(CURRENT_CARD_KEY, JSON.stringify(card));
    }

    return prize;
  }

  static async getCurrentCard(): Promise<ScratchCard | null> {
    const stored = ApplicationSettings.getString(CURRENT_CARD_KEY);
    return stored ? JSON.parse(stored) : null;
  }
}