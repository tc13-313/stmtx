import { ApplicationSettings } from '@nativescript/core';
import type { User } from '../types/auth';

const USER_KEY = 'current_user';

export class AuthService {
  static async login(email: string, password: string): Promise<User> {
    // Simulate API call
    const user: User = {
      id: '1',
      email,
      username: email.split('@')[0],
      balance: {
        stmBucks: 0,
        points: 0
      },
      achievements: [],
      scratchHistory: []
    };
    
    ApplicationSettings.setString(USER_KEY, JSON.stringify(user));
    return user;
  }

  static async logout(): Promise<void> {
    ApplicationSettings.remove(USER_KEY);
  }

  static async getCurrentUser(): Promise<User | null> {
    const stored = ApplicationSettings.getString(USER_KEY);
    return stored ? JSON.parse(stored) : null;
  }
}