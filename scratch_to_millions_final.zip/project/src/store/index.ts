import { configureStore } from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import balanceReducer from './slices/balanceSlice';
import gameReducer from './slices/gameSlice';
import rewardsReducer from './slices/rewardsSlice';

export const store = configureStore({
  reducer: {
    auth: authReducer,
    balance: balanceReducer,
    game: gameReducer,
    rewards: rewardsReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;