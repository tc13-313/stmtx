import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import type { BalanceState, BalanceUpdate } from '../../types/balance';

const initialState: BalanceState = {
  stmBucks: 0,
  points: 0,
  history: [],
  loading: false,
  error: null,
};

const balanceSlice = createSlice({
  name: 'balance',
  initialState,
  reducers: {
    updateBalance: (state, action: PayloadAction<BalanceUpdate>) => {
      state[action.payload.type] += action.payload.amount;
      state.history.unshift(action.payload);
    },
    setBalance: (state, action: PayloadAction<Pick<BalanceState, 'stmBucks' | 'points'>>) => {
      state.stmBucks = action.payload.stmBucks;
      state.points = action.payload.points;
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    setError: (state, action: PayloadAction<string | null>) => {
      state.error = action.payload;
    },
  },
});

export const {
  updateBalance,
  setBalance,
  setLoading,
  setError,
} = balanceSlice.actions;

export default balanceSlice.reducer;