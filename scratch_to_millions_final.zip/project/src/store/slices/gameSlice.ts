import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import type { GameState, ScratchCard } from '../../types/game';

const initialState: GameState = {
  dailyCardAvailable: true,
  loading: false,
  error: null,
};

const gameSlice = createSlice({
  name: 'game',
  initialState,
  reducers: {
    setCurrentCard: (state, action: PayloadAction<ScratchCard>) => {
      state.currentCard = action.payload;
    },
    setDailyCardStatus: (state, action: PayloadAction<boolean>) => {
      state.dailyCardAvailable = action.payload;
      if (!action.payload) {
        state.lastDailyCard = new Date();
      }
    },
    setLoading: (state, action: PayloadAction<boolean>) => {
      state.loading = action.payload;
    },
    setError: (state, action: PayloadAction<string | null>) => {
      state.error = action.payload;
    },
  },
});

export const { setCurrentCard, setDailyCardStatus, setLoading, setError } = gameSlice.actions;
export default gameSlice.reducer;